package com.cg.hms.service;

import java.util.ArrayList;

import com.cg.hms.bean.BookingDetailsBean;
import com.cg.hms.bean.HotelBean;
import com.cg.hms.bean.RoomBean;
import com.cg.hms.bean.UserBean;

public interface IHotelService {

    /*User Part*/
	public int addUserDetails(UserBean u); //User Registration
	
	public UserBean login(String userName, String password,UserBean userbean); //User Login
	

	public ArrayList<HotelBean> selecthotel(String location);  //Select Hotel

	public ArrayList<RoomBean> selectroom(int id); //Select Room

    public int BookRoom(BookingDetailsBean bookbeanobj); //Book Room
 
	/*ADMIN PART*/
	/*HOTEL MANAGEMENT*/
	
	public int addHotelServ(HotelBean hotelbean); //Add Hotel

	public int deleteHotelById(int deletehotelid); //Delete Hotel ID

	public void updateHotelDetails(HotelBean hotelBean); // Update Hotel Details For Updating
	ArrayList<HotelBean> searchHotelById(int id);   //Search Hotel By ID
	
	/* ROOM MANGEMENT*/
	int addRoomServ(RoomBean roombean); //Add Room
	
	public int deleteroomById(int deleteroomid);  //Delete Room ID
	
	public void updateRoomDetails(RoomBean roomBean); // Update Room Details
	
	ArrayList<RoomBean> searchRoomById(int id); //Search Room By ID For Updating

	/*GENERATE REPORT*/
	public ArrayList<HotelBean> getAllHotels(); //View All Hotels

	public ArrayList<BookingDetailsBean> viewBookingByDate(String bookdate); //View Booking By Date

	public ArrayList<UserBean> viewGuestList(int hotelid); //View Guest List
	
	public ArrayList<BookingDetailsBean> viewBookingDetails(int hotel); //View Booking Details
	
	
	
	
	
	
	
	

	

	
	

	
	





}
