package com.cg.hms.dao;

import java.util.ArrayList;

import com.cg.hms.bean.BookingDetailsBean;
import com.cg.hms.bean.HotelBean;
import com.cg.hms.bean.RoomBean;
import com.cg.hms.bean.UserBean;

public interface IHotelDao 
{
	public int addUserDetails(UserBean u);

	public int addHotelServ(HotelBean hotelbean);

	public int addRoomServ(RoomBean roombean);

	public ArrayList<HotelBean> getAllHotels();



	public int deleteHotelById(int deletehotelid);

	
	public BookingDetailsBean bookHotel(BookingDetailsBean bookBean, int perNight);
	
	
	
	

	public int deleteroomById(int deleteroomid);

	public ArrayList<HotelBean> selecthotel(String location);

	public ArrayList<RoomBean> selectroom(int id);
	/******UPDATE HOTEL********/
	public void updateHotelDetails(HotelBean hotelBean);
	public ArrayList<HotelBean> searchHotelById(int id);
	
	
	
	public void updateRoomDetails(RoomBean roomBean);
	
	ArrayList<RoomBean> searchRoomById(int id);
/*
	public int BookRoom(int hotelId, int perNight, int roomId, String bookedTo,
			String bookedFrom, int numberOfAdults, int amount);
*/
	public ArrayList<BookingDetailsBean> viewBookingDetails(int hotel);

	public ArrayList<BookingDetailsBean> viewBookingByDate(String bookdate);
	public ArrayList<UserBean> viewGuestList(int hotelid);

	public UserBean login(String userName, String password, UserBean userbean);

	public int BookRoom(BookingDetailsBean bookbeanobj);

	/*public int StoreBookingDetails(BookingDetailsBean bookbeanobj,int amount,int userId);
*/

}
