package com.cg.hms.dao;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;
import javax.transaction.Transactional;

import org.springframework.context.annotation.Bean;
import org.springframework.stereotype.Repository;

import com.cg.hms.bean.BookingDetailsBean;
import com.cg.hms.bean.HotelBean;
import com.cg.hms.bean.RoomBean;
import com.cg.hms.bean.UserBean;
@Repository
@Transactional
public class HotelDao implements IHotelDao
{
	@PersistenceContext
	private EntityManager em;
	/***************Registration****************/
	@Override
	public int addUserDetails(UserBean u) {
		em.persist(u);
		System.out.println(u.getUserId());
		return u.getUserId();

	}
	/****************************Login******************************/
	@Override
	public UserBean login(String userName, String password, UserBean userbean) {
			Query qry = em.createNamedQuery("userLoginQry");
			qry.setParameter("user",userbean.getUserName());
			qry.setParameter("pass",userbean.getPassword());
			try
			{
			userbean=(UserBean) qry.getSingleResult();
			System.out.println(userbean);
			}
			catch(Exception e)
			{
				System.out.println(e.getMessage());
			}
			return userbean;
		}

	@Override
	public int addHotelServ(HotelBean hotelbean) {
		System.out.println("inside dao");
		em.persist(hotelbean);
		System.out.println(hotelbean.getHotelid());
		return hotelbean.getHotelid();
	}

	@Override
	public int addRoomServ(RoomBean roombean) {
		System.out.println("inside dao");
		em.persist(roombean);


		return roombean.getRoomid();
	}

	@Override
	public ArrayList<HotelBean> getAllHotels() {
		Query qry=em.createNamedQuery("getAllHotels");
		return (ArrayList<HotelBean>) qry.getResultList();
	}


	@Override
	public int deleteHotelById(int deletehotelid) {
		Query deleteQuery=em.createQuery("delete HotelBean where hotelid =:delhid");
		deleteQuery.setParameter("delhid",deletehotelid);
		int result = deleteQuery.executeUpdate();
		return result;
	}
	@Override
	public int deleteroomById(int deleteroomid) {

		Query deleteQuery=em.createQuery("delete RoomBean where roomid =:delrid");
		deleteQuery.setParameter("delrid",deleteroomid);
		int result = deleteQuery.executeUpdate();
		return result;
	}
	@Override
	public ArrayList<HotelBean> selecthotel(String location) {

		Query query=em.createQuery("select r from HotelBean r where r.city=:location");
		query.setParameter("location", location);

		return (ArrayList<HotelBean>) query.getResultList();
	}
	@Override
	public ArrayList<RoomBean> selectroom(int id) {
		Query query=em.createQuery("select r from RoomBean r where r.hotelid=:id and availability=true");
		query.setParameter("id", id);
		return (ArrayList<RoomBean>) query.getResultList();
	}
	/******************UPDATE HOTEL**************/
	@Override
	public void updateHotelDetails(HotelBean hotelBean) {

		String desc=hotelBean.getDescription();
		int amount=hotelBean.getAvgratepernight();
		int id=hotelBean.getHotelid();
		int amt = Math.abs(hotelBean.getAvgratepernight()); 
		//int id=hotelBean.getHotelid();

		Query updateHotel = em.createQuery("update HotelBean h set h.description=:descr, h.avgratepernight=:rate where h.hotelid=:idd ");
		updateHotel.setParameter("descr", desc);
		updateHotel.setParameter("rate", amt);
		updateHotel.setParameter("idd", id);
		updateHotel.executeUpdate();
	}
	@Override
	public ArrayList<HotelBean> searchHotelById(int id) {
		Query query=em.createQuery("select r from HotelBean r where r.hotelid=:id");
		query.setParameter("id", id);

		return (ArrayList<HotelBean>) query.getResultList();

	}
/***************************************************************************************************************/
	
	
	@Override
	public void updateRoomDetails(RoomBean roomBean) {
		String type=roomBean.getRoomtype();
		int amt=roomBean.getPernightrate();
		int id=roomBean.getRoomid();
		Query updateRoom=em.createQuery("update RoomBean r set r.roomtype=:rtype, r.pernightrate=:amount where r.roomid=:rid");
		updateRoom.setParameter("rtype", type);
		updateRoom.setParameter("amount", amt);
		updateRoom.setParameter("rid", id);
			
	}
	@Override
	public ArrayList<RoomBean> searchRoomById(int id) {
		Query query=em.createQuery("select r from RoomBean r where r.roomid=:id");
		query.setParameter("id", id);

		return (ArrayList<RoomBean>) query.getResultList();
		
	}


	/*@Override
	public int BookRoom(int hotelId, int perNight, int roomId,
			String bookedTo, String bookedFrom, int numberOfAdults,int amount) {
		BookingDetailsBean bean;
		int id=hotelId;
		int roomid=roomId;
		String bookedfrom= bookedFrom;
		String bookedto= bookedTo;
		int amt=amount;
		int numberofadults=numberOfAdults;
		//int userid=bean.getUserId();
		bean=new BookingDetailsBean(roomid,bookedfrom,bookedto,numberofadults,amt,id);
		
		
		em.persist(bean);

		return bean.getBookingId()+bean.getAmount();}*/

	@Override
	public ArrayList<BookingDetailsBean> viewBookingDetails(int hotel) {
		Query query=em.createQuery("select b from BookingDetailsBean  b where b.hotelid=:hotel");
		query.setParameter("hotel", hotel);

		return (ArrayList<BookingDetailsBean>) query.getResultList();
		
	}
	@Override
	public ArrayList<BookingDetailsBean> viewBookingByDate(String bookdate) {
		Query query=em.createQuery("select b from BookingDetailsBean  b where b.bookedFrom=:bookdate");
		query.setParameter("bookdate", bookdate);

		return  (ArrayList<BookingDetailsBean>) query.getResultList();
	}
	@Override
	public ArrayList<UserBean> viewGuestList(int hotelid) {
		Query query=em.createQuery("select s from UserBean s where s.userId in(select b.userId from BookingDetailsBean b where b.hotelid=:hotelid)");
		query.setParameter("hotelid", hotelid);

		return  (ArrayList<UserBean>) query.getResultList();
	}
	/*@Override
	public int StoreBookingDetails(BookingDetailsBean bookbeanobj,int amount,int userId) {
		em.persist(bookbeanobj);
		System.out.println(bookbeanobj.getUserId());
		return bookbeanobj.getUserId()+bookbeanobj.getAmount();
	}
	
		*/
	@Override
	public BookingDetailsBean bookHotel(BookingDetailsBean bookBean,int perNight) {
		
		em.persist(bookBean);
		System.out.println(bookBean.getBookingId());
		return bookBean;
	}
	@Override
	public int BookRoom(BookingDetailsBean bookbeanobj) {
		em.persist(bookbeanobj);
		return bookbeanobj.getBookingId();
	}
	
	
	
	

}
