package com.cg.hms.bean;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.NamedQuery;
import javax.persistence.Table;

@Entity

@Table(name="RoomDetails")
public class RoomBean {
	@Id
	@GeneratedValue
		@Column(name="room_id")
    private int roomid;
	
 		@Column(name="hotel_id")
	private int hotelid;
		
		@Column(name="room_no")
	private String roomno;
		
		@Column(name="room_type")
	private String roomtype;
		
		@Column(name="per_night_rate")
	private int pernightrate;
		
		@Column(name="availability")
	private boolean availability;
	
	/******************************************************************************************************************
	                                       Default constructor
	********************************************************************************************************************/
	public RoomBean() {
		// TODO Auto-generated constructor stub
	}

	
	
	/******************************************************************************************************************
                                          Getters&Setters
    ********************************************************************************************************************/
	
	public int getRoomid() {
		return roomid;
	}

	public void setRoomid(int roomid) {
		this.roomid = roomid;
	}

	public int getHotelid() {
		return hotelid;
	}

	public void setHotelid(int hotelid) {
		this.hotelid = hotelid;
	}

	public String getRoomno() {
		return roomno;
	}

	public void setRoomno(String roomno) {
		this.roomno = roomno;
	}

	public String getRoomtype() {
		return roomtype;
	}

	public void setRoomtype(String roomtype) {
		this.roomtype = roomtype;
	}

	public int getPernightrate() {
		return pernightrate;
	}

	public void setPernightrate(int pernightrate) {
		this.pernightrate = pernightrate;
	}

	public boolean isAvailability() {
		return availability;
	}

	public void setAvailability(boolean availability) {
		this.availability = availability;
	}



	

	/******************************************************************************************************************
                                         Parameterized constructor
    ********************************************************************************************************************/
	
	public RoomBean(int roomid, int hotelid, String roomno, String roomtype,
			int pernightrate, boolean availability) {
		super();
		this.roomid = roomid;
		this.hotelid = hotelid;
		this.roomno = roomno;
		this.roomtype = roomtype;
		this.pernightrate = pernightrate;
		this.availability = availability;
	}



	
	
	/******************************************************************************************************************
                                            To String
   ********************************************************************************************************************/
	
	
	@Override
	public String toString() {
		return "RoomBean [roomid=" + roomid + ", hotelid=" + hotelid
				+ ", roomno=" + roomno + ", roomtype=" + roomtype
				+ ", pernightrate=" + pernightrate + ", availability="
				+ availability + "]";
	}

	
}
